const express = require("express");

const {
    getWorkerRequests,
    acceptRequest
} = require("../controllers/workerController");

const router = express.Router();

router.get(
    "/:worker_id/requests",
    getWorkerRequests
);

router.post(
    "/requests/:request_id/accept",
    acceptRequest
);

module.exports = router;