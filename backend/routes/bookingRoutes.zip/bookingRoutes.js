const express = require("express");

const {
    getFarmerBookings
} = require("../controllers/bookingController");

const router = express.Router();

router.get(
    "/farmer/:farmer_id",
    getFarmerBookings
);

module.exports = router;